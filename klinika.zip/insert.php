<?php
require("connect.php");
$imie = $_POST['imie'];
$nazwisko = $_POST['nazwisko'];
$data_urodzenia = $_POST['data_urodzenia'];
$adres = $_POST['adres'];
$numer_telefonu = $_POST['numer_telefonu'];
$pesel = $_POST['pesel'];
$sql = "INSERT INTO pacjenci(id_pacjenta, imie, nazwisko, data_urodzenia, adres, numer_telefonu, pesel)
VALUES('','$imie','$nazwisko','$data_urodzenia','$adres','$numer_telefonu','$pesel')";
$wynik = $connect->query($sql);
?>